from setuptools import setup, find_packages

setup(
    name='retro_star',
    version='',
    packages=find_packages(),
    url='',
    license='',
    author='binghong',
    author_email='binghong@gatech.edu',
    description='Retro* for retrosynthetic planning'
)
