python ../mlp_inference.py --template_rule_path '../data/toy/template_rules_1.dat' \
 --model_path '../model/toy/saved_rollout_state_1_2048.ckpt'